<div>
    <div class="bg-white rounded-lg shadow p-8 min-h-[420px]">
        <div class="text-xl font-semibold text-[#ff2323] mb-4">Organization Info</div>
            
        <form wire:submit="save" enctype="multipart/form-data">
        {{-- image Upload --}}
        <div x-data="{
            isDragging: false,
            dragEnter() { this.isDragging = true; },
            dragLeave() { this.isDragging = false; },
            drop(event) {
                this.isDragging = false;
                const files = event.dataTransfer.files;
                if (files.length > 0) {                    
                    this.$refs.fileInput.files = files;
                    this.$refs.fileInput.dispatchEvent(new Event('change'));
                }
            }
        }" 
            @dragenter.prevent="dragEnter" 
            @dragover.prevent 
            @dragleave.prevent="dragLeave" 
            @drop.prevent="drop" 
            class="flex gap-0 mb-5 w-full max-w-[460px]"
        >
            <label 
                :class="{'border-dashed border-4 border-red-500 bg-red-50': isDragging}" 
                class="w-32 h-28 flex flex-col items-center justify-center rounded-l-lg border border-[#e7e7e7] bg-[#faf7fa] cursor-pointer relative overflow-hidden"
                for="fileInput"
            >
                <img src="/images/logo-upload-icon.svg" class="w-full opacity-70" />
                <input 
                    type="file" 
                    id="fileInput"
                    x-ref="fileInput"
                    wire:model="image" 
                    class="absolute inset-0 opacity-0 cursor-pointer" 
                />
            </label>

            <div 
                :class="{'bg-red-50': isDragging}" 
                class="flex-1 border border-l-0 rounded-r-lg flex flex-col items-center justify-center border-[#e7e7e7] py-5 bg-white"
            >
                @if ($image)
                    <img src="{{ $image->temporaryUrl() }}" class="w-10 h-10 object-cover mb-2 rounded-full" />
                @else
                    <img src="/images/image-icon-logo.svg" class="w-[20px] opacity-70 mb-2" />
                @endif
                <small wire:loading wire:target="image">Uploading...</small>
                <div class="font-medium text-black mb-1">Upload Logo</div>
                <div class="text-xs text-gray-400">Drag and drop or browse</div>
            </div>

            @error('image') <span class="text-red-600 text-sm mb-2">{{ $message }}</span> @enderror
        </div>


        {{-- Inputs --}}
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <input type="text" placeholder="Organisation Name" wire:model.debounce.500ms="name" class="border rounded px-3 py-2 w-full">
                @error('name') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input type="number" placeholder="Phone Number" wire:model.defer="phone" class="border rounded px-3 py-2 w-full">
                @error('phone') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <select wire:model.defer="industry" class="border rounded px-3 py-2 w-full text-gray-500">
                    <option value="">Select Industry</option>
                    <option value="IT">IT</option>
                    <option value="Education">Education</option>
                    <option value="Health">Health</option>
                </select>
                @error('industry') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>

            <div>
                <select wire:model.defer="revenue" class="border rounded px-3 py-2 w-full text-gray-500">
                    <option value="">Select Turnover</option>
                    <option value="<1Cr">&lt; 1 Cr</option>
                    <option value="1-10Cr">1-10 Cr</option>
                    <option value="10+Cr">10+ Cr</option>
                </select>
                @error('revenue') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>

            <div>
                <input type="number" placeholder="Enter Year" wire:model.defer="year" class="border rounded px-3 py-2 w-full">
                @error('year') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input type="text" placeholder="Website URL" wire:model.defer="website_url" class="border rounded px-3 py-2 w-full">
                @error('website_url') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
        </div>

        {{-- Working Days --}}
        <div class="mb-6">
            <div class="font-medium mb-2">Working Days</div>
            <div class="flex flex-wrap gap-2">
                @foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day)
                    <label>
                        <input type="checkbox" wire:model="working_days" value="{{ $day }}" class="hidden peer">
                        <span class="px-4 py-2 rounded border text-[#191919] border-[#d7d7d7] peer-checked:bg-[#ff2323] peer-checked:text-white cursor-pointer">
                            {{ $day }}
                        </span>
                    </label>
                @endforeach
                
            </div>
            @error('working_days') <span class="text-red-600 text-sm mt-3">{{ $message }}</span> @enderror
        </div>
        @if (session()->has('success'))
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show" x-transition class="text-green-600 mb-4 text-lg font-semibold text-green-800">
                {{ session('success') }}
            </div>
        @endif

        {{-- Buttons --}}
        <div class="flex items-center gap-4">
           <button type="submit" class="bg-red-600 text-white rounded px-8 py-2 font-semibold">Save & Next</button>
            <button type="button" wire:click="resetForm" class="bg-white text-[#8c8c8c] px-2 py-2 rounded border-0 underline"> Reset All</button>
        </div>
        </form>
    </div>
</div>
