<div class="flex-1 overflow-auto p-8 bg-[#f6f8fa]">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="flex justify-between items-center mb-4">
            <a href="{{ route('organisations.create') }}"
                class="bg-[#ff2323] text-white px-5 py-2 rounded-xl shadow font-medium hover:bg-[#c71313] transition inline-block">
                + Create Organisation
                </a>
        </div>

        <!-- Organisation Cards Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
            @foreach($organisations as $organisation)
                <div
                    class="bg-white rounded-xl shadow-md p-7 flex flex-col items-center justify-center relative transition hover:shadow-lg cursor-pointer hover:scale-[1.03]"
                    title="Edit Organisation">
                    <div
                        class="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-3 select-none overflow-hidden">
                        <img src="{{ $organisation->image ? asset('storage/' . $organisation->image) : 'https://via.placeholder.com/150' }}" alt="{{ $organisation->name }}"  class="w-full h-full object-cover rounded-full">
                    </div>
                    <h3 class="text-lg font-bold text-gray-800 mb-1 text-center truncate w-full">{{ $organisation->name }}</h3>
                    <div class="text-xs text-gray-500 mb-2 text-center w-full truncate">
                        {{ $organisation->industry }} | {{ $organisation->revenue }} | {{ $organisation->type }}
                    </div>
                    <div class="w-full text-center mb-1 text-[13px]">
                        <span class="font-semibold text-gray-700">Working Days:</span>
                        <span class="ml-2 text-gray-600">
                            {{ is_array($organisation->working_days) ? implode(', ', $organisation->working_days) : $organisation->working_days }}
                        </span>

                    </div>
                    <div class="w-full text-center mt-2 text-[13px]">
                        <span class="font-semibold text-gray-700">Phone:</span>
                        <span class="ml-2 text-gray-700">{{ $organisation->phone }}</span>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
