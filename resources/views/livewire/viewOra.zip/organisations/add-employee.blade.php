<div>
    <form wire:submit="save">
    <div class="border p-6 rounded border-gray-300 bg-white">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl text-[#ff2323]">Add Employee</h2>
            <button class="bg-gray-100 text-black px-6 py-2 rounded shadow hover:bg-gray-400">Import By CSV</button>
        </div>

        <table class="border-collapse border border-gray-400 w-full">
            <thead>
                <tr>
                    <th class="border border-gray-300 p-3 bg-gray-100">First Name</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Last Name</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Email</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Department</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Office</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Phone</th>
                    <th class="border border-gray-300 p-3 bg-gray-100">Role</th>
                </tr>
            </thead>
            <tbody>
                @for ($i = 0; $i < count($rows); $i++)
                    <tr>
                        <td class="border border-gray-300 p-3">
                            <input type="text" wire:model.lazy="rows.{{ $i }}.first_name" class="w-full border px-2 py-1 rounded" />
                            @error('rows.' . $i . '.first_name')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3">
                            <input type="text" wire:model.lazy="rows.{{ $i }}.last_name" class="w-full border px-2 py-1 rounded" />
                            @error('rows.' . $i . '.last_name')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3">
                            <input type="email" wire:model.lazy="rows.{{ $i }}.email" class="w-full border px-2 py-1 rounded" />
                            @error('rows.' . $i . '.email')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3">
                            <select wire:model.lazy="rows.{{ $i }}.department" class="w-full border px-2 py-1 rounded">
                                <option value="">Select Department</option>
                                @foreach($departments as $dept)
                                    <option value="{{ $dept->name }}">{{ $dept->name }}</option>
                                @endforeach
                            </select>
                            @error('rows.' . $i . '.department')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3">
                            <select wire:model.lazy="rows.{{ $i }}.office_id" class="w-full border px-2 py-1 rounded bg-gray-100" readonly>
                                <option value="">Select Office</option>
                                @foreach($offices as $office)
                                    <option value="{{ $office->id }}">{{ $office->office_name }}</option>
                                @endforeach
                            </select>
                            @error('rows.' . $i . '.office_id')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3">
                            <input type="text" wire:model.lazy="rows.{{ $i }}.phone" class="w-full border px-2 py-1 rounded" />
                            @error('rows.' . $i . '.phone')
                                <span class="text-red-600 text-xs">{{ $message }}</span>
                            @enderror
                        </td>

                        <td class="border border-gray-300 p-3 text-center">
                            <input type="checkbox" wire:click="setLead({{ $i }})" wire:model="rows.{{ $i }}.is_lead" />
                        </td>
                    </tr>
                @endfor
            </tbody>
        </table>

        <div class="inline-flex border p-2 border-gray-300 mb-4 mt-4 items-center rounded-md">
            <span class="mr-3">Add More Column</span>
            <input type="number" min="1" wire:model="addCount" class="border rounded-md border-gray-300 mr-2" style="width: 60px; height: 40px; padding-left: 5px;">
            <button type="button" wire:click="addRows" class="bg-red-600 text-white px-4 py-2 rounded shadow hover:bg-red-700">Add</button>
        </div>

        <div class="flex gap-4 justify-start mt-6">
            <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700">Save & Next</button>
            <button type="button" class="text-black px-6">Reset All</button>
        </div>

        @if (session()->has('success'))
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show" x-transition class="text-green-600 mb-4 text-lg font-semibold text-green-800">
                {{ session('success') }}
            </div>
        @endif

        @if(session()->has('error'))
            <div class="mt-4 text-red-600 font-semibold">
                {{ session('error') }}
            </div>
        @endif
    </form>
    </div>
</div>
