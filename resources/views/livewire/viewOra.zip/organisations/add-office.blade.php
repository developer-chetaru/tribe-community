<div 
    x-data 
    x-init="() => {
        function initAutocomplete() {
            const addressField = document.getElementById('address');
            const autocomplete = new google.maps.places.Autocomplete(addressField, {
                componentRestrictions: { country: ['us', 'ca', 'in'] },
                fields: ['address_components', 'geometry'],
                types: ['address'],
            });

            autocomplete.addListener('place_changed', function () {
                const place = autocomplete.getPlace();

                let address1 = '';
                let zip_code = '';

                for (const component of place.address_components) {
                    const type = component.types[0];

                    switch (type) {
                        case 'street_number':
                            address1 = `${component.long_name} ${address1}`;
                            break;
                        case 'route':
                            address1 += component.short_name;
                            break;
                        case 'postal_code':
                            zip_code = `${component.long_name}${zip_code}`;
                            break;
                        case 'postal_code_suffix':
                            zip_code = `${zip_code}-${component.long_name}`;
                            break;
                        case 'locality':
                            @this.set('city', component.long_name);
                            break;
                        case 'administrative_area_level_1':
                            @this.set('state', component.short_name);
                            break;
                        case 'country':
                            @this.set('country', component.long_name);
                            break;
                    }
                }

                @this.set('address', address1);
                @this.set('zip_code', zip_code);
            });
        }

        window.initAutocomplete = initAutocomplete;
        initAutocomplete();
    }"
>
    <form wire:submit="save" class="space-y-6 mx-auto bg-white p-6 rounded shadow">
        <!-- Office Details -->
        <h2 class="text-2xl text-[#ff2323] mb-4">Add Office</h2>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <input placeholder="Office Name" type="text" wire:model="name" class="w-full border rounded px-3 py-2">
                @error('name') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input type="number" wire:model="no_of_employees" placeholder="Number of Employees" class="w-full border rounded px-3 py-2">
                @error('no_of_employees') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <input placeholder="Phone Number" wire:model="phone" type="number" class="w-full border rounded px-3 py-2">
                @error('phone') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input id="address" placeholder="Enter Address" wire:model="address" type="text" class="w-full border rounded px-3 py-2" autocomplete="off">
                @error('address') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <input placeholder="City" type="text" wire:model="city" class="w-full border rounded px-3 py-2">
                @error('city') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input placeholder="State" type="text" wire:model="state" class="w-full border rounded px-3 py-2">
                @error('state') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <input placeholder="Zip Code" type="text" wire:model="zip_code" class="w-full border rounded px-3 py-2">
                @error('zip_code') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
            <div>
                <input placeholder="Country" type="text" wire:model="country" class="w-full border rounded px-3 py-2">
                @error('country') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
            </div>
        </div>

        <label class="inline-flex items-center mt-4">
            <input type="checkbox" wire:model="is_head_office" class="form-checkbox accent-red-500 h-5 w-5 text-red-600">
            <span class="ml-2 text-sm">Head Office</span>
        </label>

        <!-- Branch Offices -->
        <div class="border p-6 rounded border-gray-300 mt-8">
            <h2 class="text-2xl text-[#ff2323] mb-6">Branch Offices</h2>

            <table class="w-full border border-gray-300">
                <thead>
                    <tr class="bg-gray-100 text-sm">
                        <th class="border p-2">Branch</th>
                        <th class="border p-2">Address</th>
                        <th class="border p-2">Zip</th>
                        <th class="border p-2">City</th>
                        <th class="border p-2">State</th>
                        <th class="border p-2">Country</th>
                        <th class="border p-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($branches as $index => $branch)
                    <tr>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_name" placeholder="Branch Name" class="w-full border px-2 py-1 rounded">
                            @error("branches.$index.branch_name")
                                <span class="text-red-600 text-sm">{{ $message }}</span>
                            @enderror
                        </td>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_address" placeholder="Address" class="w-full border px-2 py-1 rounded">
                            @error('branches.' . $index . '.branch_address') 
                                <span class="text-red-600 text-sm">{{ $message }}</span> 
                            @enderror
                        </td>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_zip_code" placeholder="ZIP" class="w-full border px-2 py-1 rounded">
                            @error('branches.' . $index . '.branch_zip_code') 
                                <span class="text-red-600 text-sm">{{ $message }}</span> 
                            @enderror
                        </td>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_city" placeholder="City" class="w-full border px-2 py-1 rounded">
                            @error('branches.' . $index . '.branch_city') 
                                <span class="text-red-600 text-sm">{{ $message }}</span> 
                            @enderror
                        </td>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_state" placeholder="State" class="w-full border px-2 py-1 rounded">
                            @error('branches.' . $index . '.branch_state') 
                                <span class="text-red-600 text-sm">{{ $message }}</span>
                            @enderror
                        </td>
                        <td class="border p-2">
                            <input type="text" wire:model="branches.{{ $index }}.branch_country" placeholder="Country" class="w-full border px-2 py-1 rounded">
                            @error('branches.' . $index . '.branch_country') 
                                <span class="text-red-600 text-sm">{{ $message }}</span> 
                            @enderror
                        </td>
                        <td class="border p-2 text-center">
                            <button type="button" wire:click="removeBranch({{ $index }})" class="text-red-500 hover:underline">Remove</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>


            <!-- Add Branch Button -->
            <button type="button" wire:click="addBranch" class="mt-3 bg-red-600 text-white px-4 py-2 rounded">
                + Add Branch
            </button>
        </div>

        @if (session()->has('success'))
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show" x-transition class="text-green-600 mb-4 text-lg font-semibold text-green-800">
                {{ session('success') }}
            </div>
        @endif

        <!-- Form Actions -->
        <div class="flex gap-4 justify-start mt-6">
            <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded shadow hover:bg-red-700">Save </button>
            <button type="reset" class="bg-gray-300 text-black px-6 py-2 rounded shadow hover:bg-gray-400">Reset</button>
        </div>
    </form>
</div>
<!-- Google Maps API -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDZyg761r13rvaPI2-LvSyRNUwfpdvsbK0&libraries=places&callback=initAutocomplete" defer></script>
