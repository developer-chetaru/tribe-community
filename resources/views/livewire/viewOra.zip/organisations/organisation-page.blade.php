<div 
    x-data="{
        activeTab: '{{ Auth::user()->organisation ? (session('office_created') ? 'tab3-group' : 'tab2-group') : 'tab1-group' }}',
        organisationCreated: {{ Auth::user()->organisation ? 'true' : 'false' }},
        officeCreated: {{ session('office_created') ? 'true' : 'false' }},
        employeeCreated: false
    }"

    x-on:organisation-created.window="
        organisationCreated = true;
        activeTab = 'tab2-group';
    "

    x-on:office-saved.window="
        officeCreated = true;
        activeTab = 'tab3-group';
    "

    x-on:employee-saved.window="
        employeeCreated = true;
        activeTab = 'tab3-group';
    "
    class="flex-1 overflow-auto p-8 bg-[#f6f8fa]"
>
    <!-- Tab Navigation -->
    <div class="flex items-center mb-6" role="tablist">
        <button
            @click="if (!organisationCreated) activeTab = 'tab1-group'"
            :class="{
                'bg-red-600 text-white': activeTab === 'tab1-group',
                'opacity-50 cursor-not-allowed': organisationCreated
            }"
            class="tab-link px-6 py-2 rounded-md border mr-2"
            type="button"
        >
            Organisation Info
        </button>

        <button
            @click="if (organisationCreated && !officeCreated) activeTab = 'tab2-group'"
            :class="{
                'bg-red-600 text-white': activeTab === 'tab2-group',
                'opacity-50 cursor-not-allowed': !organisationCreated || officeCreated
            }"
            class="tab-link px-6 py-2 rounded-md border mr-2"
            type="button"
        >
            Add Office
        </button>

        <button
            @click="if (officeCreated && !employeeCreated) activeTab = 'tab3-group'"
            :class="{
                'bg-red-600 text-white': activeTab === 'tab3-group',
                'opacity-50 cursor-not-allowed': !officeCreated || employeeCreated
            }"
            class="tab-link px-6 py-2 rounded-md border"
            type="button"
        >
            Add Employee
        </button>
    </div>

    <!-- Tab Contents -->
    <div>
        <div x-show="activeTab === 'tab1-group'" x-cloak>
            @livewire('organisations.organisation-info')
        </div>

        <div x-show="activeTab === 'tab2-group'" x-cloak>
            @livewire('organisations.add-office', ['organisationId' => Auth::user()->org_id], key('add-office'))
        </div>

        <div x-show="activeTab === 'tab3-group'" x-cloak>
            @livewire('organisations.add-employee', ['organisationId' => Auth::user()->org_id])
        </div>
    </div>
</div>
