<div class="flex-1 overflow-auto p-8 bg-[#f6f8fa]">
		
	<div class="relative tab-group">
        <h2 class="text-xl font-bold text-[#ff2323] mb-5">Create Organisations</h2>
            <div class="flex  p-0.5 relative items-center mb-10" role="tablist">
            <div class="absolute top-1 left-0 h-10  rounded-md shadow-sm transition-all duration-300 transform scale-x-0 translate-x-0 tab-indicator z-0 bg-[#fff0f0] border-rad text-[#ff2323]"></div>

            <a href="#" class="tab-link text-sm h-11 w-[180px] flex items-center justify-center rounded-lg border text-base font-medium transition-all duration-300 relative z-1 mr-1" data-tab-target="tab1-group">
                Organization Info
            </a>
            <div class="h-[2px] w-6 bg-[#d7d7d7] mx-1"></div>
            <a href="#" class="tab-link text-sm h-11 w-[180px] flex items-center justify-center rounded-lg border text-base font-medium transition-all duration-300 relative z-1 mr-1 " data-tab-target="tab2-group">
                Add Office
            </a>
            <div class="h-[2px] w-6 bg-[#d7d7d7] mx-1"></div>
            <a href="#" class="tab-link text-sm h-11 w-[180px] flex items-center justify-center rounded-lg border text-base font-medium transition-all duration-300 relative z-1 mr-1" data-tab-target="tab3-group">
                Add Employee
            </a>
            
            </div>
			<div class="mt-4 tab-content-container">
			    <div id="tab1-group" class="tab-content text-slate-800 block">
				    <div class="bg-white rounded-lg shadow p-8 min-h-[420px]">
						<div class="text-xl font-semibold text-[#ff2323] mb-4">Organization Info</div>
                           
                        <form wire:submit="save" enctype="multipart/form-data">
                        {{-- image Upload --}}
                        <div>
                            <div class="flex gap-0 mb-5 w-full max-w-[460px]">
                            
                                <label class="w-32 h-28 flex flex-col items-center justify-center rounded-l-lg border border-[#e7e7e7] bg-[#faf7fa] cursor-pointer relative overflow-hidden">
                                    <img src="/images/logo-upload-icon.svg" class="w-full opacity-70" />
                                    <input type="file" wire:model="image" class="absolute inset-0 opacity-0 cursor-pointer" />
                                    
                                </label>

                                <div class="flex-1 border border-l-0 rounded-r-lg flex flex-col items-center justify-center border-[#e7e7e7] py-5 bg-white">
                                    @if ($image)
                                        <img src="{{ $image->temporaryUrl() }}" class="w-10 h-10 object-cover mb-2 rounded-full" />
                                    @else
                                        <img src="/images/image-icon-logo.svg" class="w-[20px] opacity-70 mb-2" />
                                    @endif
                                    <small wire:loading wire:target="image">Uploading...</small>
                                    <div class="font-medium text-black mb-1">Upload Logo</div>
                                    <div class="text-xs text-gray-400">Drag and drop or browse</div>
                                </div>
                                
                            </div>
                            @error('image') <span class="text-red-600 text-sm mb-2">{{ $message }}</span> @enderror
                        </div>

                        {{-- Inputs --}}
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <input type="text" placeholder="Organisation Name" wire:model.debounce.500ms="name" class="border rounded px-3 py-2 w-full">
                                @error('name') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <input type="number" placeholder="Phone Number" wire:model.defer="phone" class="border rounded px-3 py-2 w-full">
                                @error('phone') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <select wire:model.defer="industry" class="border rounded px-3 py-2 w-full text-gray-500">
                                    <option value="">Select Industry</option>
                                    <option value="IT">IT</option>
                                    <option value="Education">Education</option>
                                    <option value="Health">Health</option>
                                </select>
                                @error('industry') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>

                            <div>
                                <select wire:model.defer="revenue" class="border rounded px-3 py-2 w-full text-gray-500">
                                    <option value="">Select Turnover</option>
                                    <option value="<1Cr">&lt; 1 Cr</option>
                                    <option value="1-10Cr">1-10 Cr</option>
                                    <option value="10+Cr">10+ Cr</option>
                                </select>
                                @error('revenue') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>

                            <div>
                                <input type="number" placeholder="Enter Year" wire:model.defer="year" class="border rounded px-3 py-2 w-full">
                                @error('year') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <input type="url" placeholder="Website URL" wire:model.defer="website_url" class="border rounded px-3 py-2 w-full">
                                @error('website_url') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                            </div>
                        </div>

                        {{-- Working Days --}}
                        <div class="mb-6">
                            <div class="font-medium mb-2">Working Days</div>
                            <div class="flex flex-wrap gap-2">
                                @foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day)
                                    <label>
                                        <input type="checkbox" wire:model="working_days" value="{{ $day }}" class="hidden peer">
                                        <span class="px-4 py-2 rounded border text-[#191919] bg-white border-[#d7d7d7] peer-checked:bg-[#ff2323] peer-checked:text-white cursor-pointer">
                                            {{ $day }}
                                        </span>
                                    </label>
                                @endforeach
                                
                            </div>
                            @error('working_days') <span class="text-red-600 text-sm mt-3">{{ $message }}</span> @enderror
                        </div>
                         @if (session()->has('success'))
                            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show" x-transition class="text-green-600 mb-4 text-lg font-semibold text-green-800">
                                {{ session('success') }}
                            </div>
                        @endif

                        {{-- Buttons --}}
                        <div class="flex items-center gap-4">
                            <button type="submit" class="bg-[#ff2323] text-white rounded px-8 py-2 font-semibold">Save & Next</button>
                            <button type="button" wire:click="resetForm" class="bg-white text-[#8c8c8c] px-2 py-2 rounded border-0 underline"> Reset All</button>
                        </div>
                    </form>
				    </div>
			    </div>

			    <div id="tab2-group" class="tab-content text-slate-800 hidden">
			      <form class="space-y-6 mx-auto bg-white p-6 rounded shadow">
                    <div>
                        <h2 class="text-2xl text-[#ff2323]">Add Office</h2>
                        
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <input placeholder="Office Name" type="text" name="officeName" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">Office name must be at least 2 characters</p>
                        </div>
                        <div>
                            <input type="number" placeholder="Number of Employees" name="employees" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">Number of employees must be digits only</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-4">
                        <div>
                            <input placeholder="Phone Number" type="text" name="phone" class="w-full border rounded px-3 py-2"><p class="text-red-500 text-sm hidden">Phone number must be 7 to 15 digits</p>
                        </div>
                        <div>
                            <div class="">
                                <input name="address" placeholder="Enter Address" class="w-full border rounded px-3 py-2 pac-target-input" value="" autocomplete="off">
                            </div>
                            <p class="text-red-500 text-sm hidden">Address must be at least 5 characters</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-4">
                        <div>
                            <input type="text" placeholder="City" name="city" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">City name must be at least 2 characters</p>
                        </div>
                        <div>
                            <input type="text" placeholder="State" name="state" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">State name must be at least 2 characters</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <input placeholder="Zip Code" type="text" name="zip" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">ZIP code must be between 3 to 10 digits</p>
                        </div>
                        <div>
                            <input placeholder="Country" type="text" name="country" class="w-full border rounded px-3 py-2">
                            <p class="text-red-500 text-sm hidden">Country name must be at least 2 characters</p>
                        </div>
                    </div>
                    <div>
                        <label class="inline-flex items-center mt-4">
                            <input type="checkbox" name="is_head_office" class="form-checkbox accent-red-500 h-5 w-5 text-red-600"><span class="ml-2 text-sm">Head Office</span>
                        </label>
                    </div>
                    <div class="border p-6 rounded border-gray-300">
                        <h2 class="text-2xl text-[#ff2323] mb-6">Branch Office</h2>
                        <table class="border-collapse border border-gray-400 ... w-full">
                            <thead>
                                <tr>
                                <th class="border border-gray-300 p-2 ... ">Branch</th>
                                <th class="border border-gray-300 p-2 ...">Address</th>
                                <th class="border border-gray-300 p-2 ...">Zip Code</th>
                                <th class="border border-gray-300 p-2 ...">City</th>
                                <th class="border border-gray-300 p-2 ...">State</th>
                                <th class="border border-gray-300 p-2 ...">Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <td class="border border-gray-300 p-2 ...">Branch Name</td>
                                <td class="border border-gray-300 p-2 ...">Type Address</td>
                                <td class="border border-gray-300 p-2 ...">Type Code</td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select City</option></select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select State</option> </select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select  Country</option></select></td>
                                </tr>
                                <tr>
                                <td class="border border-gray-300 p-2 ...">Branch Name</td>
                                <td class="border border-gray-300 p-2 ...">Type Address</td>
                                <td class="border border-gray-300 p-2 ...">Type Code</td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select City</option></select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select State</option> </select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select  Country</option></select></td>
                                </tr>
                                <tr>
                                <td class="border border-gray-300 p-2 ...">Branch Name</td>
                                <td class="border border-gray-300 p-2 ...">Type Address</td>
                                <td class="border border-gray-300 p-2 ...">Type Code</td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select City</option></select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select State</option> </select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select  Country</option></select></td>
                                </tr>
                                <tr>
                                <td class="border border-gray-300 p-2 ...">Branch Name</td>
                                <td class="border border-gray-300 p-2 ...">Type Address</td>
                                <td class="border border-gray-300 p-2 ...">Type Code</td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select City</option></select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select State</option> </select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select  Country</option></select></td>
                                </tr>
                                <tr>
                                <td class="border border-gray-300 p-2 ...">Branch Name</td>
                                <td class="border border-gray-300 p-2 ...">Type Address</td>
                                <td class="border border-gray-300 p-2 ...">Type Code</td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select City</option></select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select State</option> </select></td>
                                <td class="border border-gray-300 p-2 ..."><select><option>Select  Country</option></select></td>
                                </tr>
                            </tbody>
                            </table>
                            <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded shadow hover:bg-red-700">Add Branch Office</button>
                    </div>
                    <div class="flex gap-4 justify-start mt-6">
                        <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded shadow hover:bg-red-700">Add Branch Office</button>
                        <button type="button" class="bg-gray-300 text-black px-6 py-2 rounded shadow hover:bg-gray-400">Next</button>
                        <button type="button" class=" text-black px-6 py-2 rounded  hover:bg-gray-400 bg-red-600 text-white">Save</button>
                        <button type="button" class="text-black px-6 ">Reset All</button>
                    </div>


				</form>

			    </div>

			    <div id="tab3-group" class="tab-content text-slate-800 hidden">
			      <p>We're not always in the position that we want to be at. We're constantly growing. We're constantly making mistakes. We're constantly trying to express ourselves and actualize our dreams.</p>
			    </div>
			     
			</div>
	</div>
</div>