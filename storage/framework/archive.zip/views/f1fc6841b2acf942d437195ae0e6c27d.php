<div x-cloak
     x-data="sidebarComponent()"
     :class="sidebarClass"
     class="flex flex-col h-screen bg-white text-black"
>
    <!-- Header: Logo + Toggle Button -->
    <div class="flex items-center justify-between p-4 border-b border-gray-200 flex-shrink-0">
        <template x-if="$store.sidebar.open">
            <img src="<?php echo e(asset('images/logo-tribe.svg')); ?>" class="w-32" />
        </template>

        <button @click="$store.sidebar.toggle()">
            <!-- Open icon -->
            <template x-if="!$store.sidebar.open">
                <img src="<?php echo e(asset('images/navigation-active.svg')); ?>" class="h-6 w-6" />
            </template>

            <!-- Close icon -->
            <template x-if="$store.sidebar.open">
                <img src="<?php echo e(asset('images/navigation-icon.svg')); ?>" class="h-6 w-6" />
            </template>
        </button>
    </div>

    <!-- Sidebar menu: scrollable -->
    <div  class="p-3 space-y-1 flex-1 overflow-y-auto">
      
            <a href="/dashboard"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
   :class="[
       $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
       window.location.pathname === '/dashboard' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700'
   ]">
    
    <!-- Dynamic image based on active route -->
    <img 
        :src="window.location.pathname === '/dashboard' 
            ? '<?php echo e(asset('images/dashboard-active.svg')); ?>' 
            : '<?php echo e(asset('images/dashboard.svg')); ?>'" 
        class="h-5 w-5" />

    <span x-show="$store.sidebar.open" x-transition class="text-sm">Dashboard</span>
</a>
      
      
      <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>

    <a href="<?php echo e(route('organisations.index')); ?>"
       class="flex items-center p-2.5 rounded-xl transition"
       :class="[
           $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
           window.location.pathname === '<?php echo e(route('organisations.index', [], false)); ?>' 
               ? 'bg-red-100 text-red-600 font-semibold' 
               : 'text-gray-700 hover:bg-gray-100'
       ]">

        <!-- Dynamic icon -->
        <img 
            :src="window.location.pathname === '<?php echo e(route('organisations.index', [], false)); ?>' 
                ? '<?php echo e(asset('images/organisations-active.svg')); ?>' 
                : '<?php echo e(asset('images/organisations.svg')); ?>'" 
            class="h-5 w-5" />

        <!-- Show label only if sidebar is open -->
        <span x-show="$store.sidebar.open" x-transition class="text-sm">
            Organisations
        </span>
    </a>
      <?php endif; ?>
      
<?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'organisation_user|organisation_admin|basecamp')): ?>
    <a href="<?php echo e(route('hptm.list')); ?>"
       class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
      :class="[
               $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
               window.location.pathname === '<?php echo e(route('hptm.list', [], false)); ?>' 
                   ? 'bg-red-100 text-red-600 font-semibold' 
                   : 'text-gray-700 hover:bg-gray-100'
           ]"
      >
        <img 
                :src="window.location.pathname === '<?php echo e(route('hptm.list', [], false)); ?>' 
                    ? '<?php echo e(asset('images/organisations-active.svg')); ?>' 
                    : '<?php echo e(asset('images/organisations.svg')); ?>'" 
                class="h-5 w-5" />


        <span x-show="$store.sidebar.open" x-transition class="text-sm">HPTM</span>
    </a>
 <?php endif; ?>

<?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'organisation_user|organisation_admin')): ?>
    <a href="<?php echo e(route('myteam.list')); ?>"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
  :class="[
           $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
           window.location.pathname === '<?php echo e(route('myteam.list', [], false)); ?>' 
               ? 'bg-red-100 text-red-600 font-semibold' 
               : 'text-gray-700 hover:bg-gray-100'
       ]"
  >
    <img 
            :src="window.location.pathname === '<?php echo e(route('myteam.list', [], false)); ?>' 
                ? '<?php echo e(asset('images/my-teammate-icon-active.svg')); ?>' 
                : '<?php echo e(asset('images/my-teammate-icon-default.svg')); ?>'" 
            class="h-5 w-5" />


    <span x-show="$store.sidebar.open" x-transition class="text-sm">My Teammates</span>
</a>
<?php endif; ?>

 <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>
        <!-- Offloading -->
    <a href="#"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
   :class="[
       $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
       window.location.pathname === '' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700'
   ]">
    
    <img 
        :src="window.location.pathname === '' 
            ? '<?php echo e(asset('images/offloading-active.svg')); ?>' 
            : '<?php echo e(asset('images/offloading.svg')); ?>'" 
        class="h-5 w-5" />

    <span x-show="$store.sidebar.open" x-transition class="text-sm">Offloading</span>
</a>
     <?php endif; ?>


         
      <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>
      <a href="<?php echo e(route('basecampuser')); ?>"
       class="flex items-center p-2.5 rounded-xl transition"
       :class="[
           $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
           window.location.pathname === '<?php echo e(route('basecampuser', [], false)); ?>' 
               ? 'bg-red-100 text-red-600 font-semibold' 
               : 'text-gray-700 hover:bg-gray-100'
       ]">

        <!-- Dynamic icon -->
        <img 
            :src="window.location.apthname === '<?php echo e(route('basecampuser', [], false)); ?>' 
                ? '<?php echo e(asset('images/basecamnp-user-active.svg')); ?>' 
                : '<?php echo e(asset('images/basecamnp-user-default.svg')); ?>'" 
            class="h-5 w-5" />

        <!-- Show label only if sidebar is open -->
        <span x-show="$store.sidebar.open" x-transition class="text-sm">
            Basecamp User
        </span>
    </a>
      
        <?php endif; ?>
      
	    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>

    <!-- Risks -->
    <a href="#"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
   :class="[
       $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
       window.location.pathname === '' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700'
   ]">
    
    <img 
        :src="window.location.pathname === '' 
            ? '<?php echo e(asset('images/risk-active.svg')); ?>' 
            : '<?php echo e(asset('images/risk.svg')); ?>'" 
        class="h-5 w-5" />

    <span x-show="$store.sidebar.open" x-transition class="text-sm">Risks</span>
</a>
      
     <?php endif; ?>
          
      
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>
    <!-- kudos -->
    <a href="#"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
   :class="[
       $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
       window.location.pathname === '' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700'
   ]">
    
    <img 
        :src="window.location.pathname === '' 
            ? '<?php echo e(asset('images/kudos-active.svg')); ?>' 
            : '<?php echo e(asset('images/kudos.svg')); ?>'" 
        class="h-5 w-5" />

    <span x-show="$store.sidebar.open" x-transition class="text-sm">Kudos</span>
</a>
   <?php endif; ?>
          
    <!-- notification -->
     <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>
    <a href="#"
   class="flex items-center p-2.5 rounded-xl hover:bg-gray-100 transition"
   :class="[
       $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
       window.location.pathname === '' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700'
   ]">
    
    <img 
        :src="window.location.pathname === '' 
            ? '<?php echo e(asset('images/notification-active.svg')); ?>' 
            : '<?php echo e(asset('images/notification.svg')); ?>'" 
        class="h-5 w-5" />

    <span x-show="$store.sidebar.open" x-transition class="text-sm">Send Notification</span>
</a>
     
  <?php endif; ?>
<?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'super_admin')): ?>
<!-- Settings Menu -->
<div 
    x-data="{ open: <?php echo e(request()->is('department*') || request()->is('directing*') || request()->is('connecting*') || request()->is('personality-type*') || request()->is('supercharging*') || request()->is('diagnostics*') || request()->is('principles*') || request()->is('hipb*') || request()->is('tribometer*') 
|| request()->is('reflection*') || request()->is('principles*') || request()->is('industries*')  || request()->is('learning-checklist*') || request()->is('learning-types*') || request()->is('team-feedback*')
 ? 'true' : 'false'); ?> }">


  <!-- Parent Button -->
<button @click="open = !open"
    :class="[
        'flex items-center w-full p-2.5 rounded-xl transition',
        $store.sidebar.open ? 'space-x-3 justify-start' : 'justify-center',
        '<?php echo e(request()->is('department*') || request()->is('directing*') || request()->is('connecting*') || request()->is('personality-type*') || request()->is('supercharging*') || request()->is('diagnostics*') || request()->is('principles*') || request()->is('hipb*') 
             || request()->is('learning-checklist*')  || request()->is('industries*') ||  request()->is('learning-types*') 
            || request()->is('team-feedback*') || request()->is('learning-types*') 
            
         
            ? 'bg-red-100 text-red-600 font-semibold' 
            : 'text-gray-700 hover:bg-gray-100'); ?>'
    ]">

    <!-- Icon -->
  <img 
    src="<?php echo e(request()->is('department*') || request()->is('industries*') || request()->is('directing*') || request()->is('reflection*') || request()->is('principles*') || request()->is('learning-checklist*') || request()->is('learning-types*') || request()->is('team-feedback*') ? asset('images/setting-active.svg') : asset('images/setting.svg')); ?>" 
    class="h-5 w-5" 
/>

    <!-- Text + Arrow only if sidebar open -->
    <template x-if="$store.sidebar.open">
        <div class="flex items-center flex-1 ml-2">
            <span class="text-sm">Setting</span>
            <svg class="w-3 h-3 transition-transform ml-auto"
                 :class="open ? 'rotate-180' : ''"
                 fill="currentColor" viewBox="0 0 448 512">
                <path d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 
                         19.029-46.059h384.569c23.975 0 35.999 29.089 
                         19.029 46.059L240.971 381.476c-10.496 
                         10.496-27.561 10.496-38.057 0z"/>
            </svg>
        </div>
    </template>
</button>

    <!-- Submenus -->
    <div x-show="open && $store.sidebar.open" x-transition 
         class="ml-6 mt-1 space-y-1 border-l border-gray-200 pl-3">

        
        <a href="<?php echo e(url('/department')); ?>"
            class="flex items-center space-x-3  ml-3  p-2 rounded text-sm w-full
            <?php echo e(request()->is('department*') ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700 hover:bg-gray-100'); ?>">
       
            <img 
    src="<?php echo e(request()->is('department*')  ? asset('images/departement-active.svg') : asset('images/departement (1).svg')); ?>" 
    class="h-5 w-5" 
/>


            <span>Department</span>
        </a>

 

        <a href="<?php echo e(url('/industries')); ?>"
            class="flex items-center space-x-3  ml-3  p-2 rounded text-sm w-full
            <?php echo e(request()->is('industries*') ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700 hover:bg-gray-100'); ?>">
       
            <img 
    src="<?php echo e(request()->is('industries*')  ? asset('images/industries-icon-active.svg') : asset('images/industries-icon.svg')); ?>" 
    class="h-5 w-5" 
/>


            <span>Industries</span>
        </a>

 
<!-- DirectingDropdown -->

<div     x-data="{ 
        open: <?php echo e(request()->is('directing*')

 ? 'true' : 'false'); ?> 
    }"  class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700 <?php echo e(request()->is('directing*') ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700 hover:bg-gray-100'); ?>

 ">
        <div class="flex items-center space-x-3">
          <img 
    src="<?php echo e(request()->is('directing*')  ? asset('images/directing-active.svg') : asset('images/directing.svg')); ?>" 
    class="h-5 w-5" 
/>

            <span class="text-sm">Directing</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3 ">
        <a href="<?php echo e(route('directing-value.list')); ?>" 
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100 <?php echo e(request()->is('directing*') ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700 hover:bg-gray-100'); ?>">Directing Values</a>

    </div>
</div>


<div x-data="{ open: false }" class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/connecting.svg')); ?>" class="h-5 w-5" />
            <span class="text-sm">Connecting</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
        <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Questions</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Description</a>
    </div>
</div>


<div x-data="{ open: false }" class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/personality-type.svg')); ?>" class="h-5 w-5" />
            <span class="text-sm">Personality Type</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
        <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Question</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Options</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Value</a>
    </div>
</div>


<div x-data="{ open: false }" class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/personality-type.svg')); ?>" class="h-5 w-5" />
            <span class="text-sm">Supercharging</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
        <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Cultural Structure Questions</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Motivation Questions</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Motivation Value</a>
    </div>
</div>


<div x-data="{ open: false }" class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/diagnostics.svg')); ?>" class="h-5 w-5" />
            <span class="text-sm">Diagnostics</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
        <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Question</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Options</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Value</a>
    </div>
</div>

<div x-data="{ open: false }" class="ml-3 space-y-1">
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-700">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/tribometer.svg')); ?>" class="h-5 w-5" />
            <span class="text-sm">Tribometer</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
       <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Question</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Options</a>
              <a href="#"
            class="block text-sm text-gray-700 p-2 rounded hover:bg-gray-100">Value</a>
    </div>
</div>


      
<div 
    x-data="{ 
        open: <?php echo e(request()->is('reflection*') || request()->is('principles*') || request()->is('learning-checklist*') || request()->is('learning-types*') || request()->is('team-feedback*')

 ? 'true' : 'false'); ?> 
    }" 
    class="ml-3 space-y-1"
>
    <!-- Parent Button -->
    <button @click="open = !open"
        class="flex items-center justify-between w-full p-2.5 rounded-xl transition 
        <?php echo e(request()->is('reflection*') || request()->is('principles*') || request()->is('learning-checklist*') || request()->is('learning-types*') || request()->is('team-feedback*') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
        <div class="flex items-center space-x-3">
            <img 
    src="<?php echo e(request()->is('reflection*') || request()->is('principles*') || request()->is('learning-types*') ||
         request()->is('learning-checklist*') ||  request()->is('team-feedback*') ? asset('images/conversation-active.svg') : asset('images/hipb.svg')); ?>" 
    class="h-5 w-5" 
/>

          
            <span class="text-sm">HPTM</span>
        </div>
        <svg class="w-3 h-3 transition-transform" :class="open ? 'rotate-180' : ''" fill="currentColor"
            viewBox="0 0 448 512">
            <path
                d="M207.029 381.476L12.686 187.132c-16.97-16.97-4.946-46.059 19.029-46.059h384.569c23.975 0 35.999 29.089 19.029 46.059L240.971 381.476c-10.496 10.496-27.561 10.496-38.057 0z" />
        </svg>
    </button>

    <!-- Dropdown items -->
    <div x-show="open" x-transition class="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3">
        <a href="<?php echo e(route('admin.reflections.index')); ?>" class="block text-sm p-2 rounded <?php echo e(request()->routeIs('admin.reflections.index') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
            Reflection
        </a>
        <a href="<?php echo e(route('principles')); ?>"
            class="block text-sm p-2 rounded 
            <?php echo e(request()->is('principles*') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
            Principles
        </a>
        <a href="<?php echo e(route('learningchecklist.list')); ?>"
            class="block text-sm p-2 rounded 
            <?php echo e(request()->is('learning-checklist*') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
            Learning Checklist
        </a>
        <a href="<?php echo e(route('learningtype.list')); ?>"
            class="block text-sm p-2 rounded 
            <?php echo e(request()->is('learning-types*') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
            Checklist Type
        </a>
        <a href="<?php echo e(route('team-feedback.list')); ?>"
            class="block text-sm p-2 rounded 
            <?php echo e(request()->is('team-feedback*') ? 'bg-red-100 text-red-600' : 'text-gray-700 hover:bg-gray-100'); ?>">
            Individual Questionnaire
        </a>
    </div>
</div>

     
    </div>
</div>
<?php endif; ?>

    </div>
</div>

<!-- Alpine Global Store + Sidebar Component -->
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.store('sidebar', {
            open: true,
            menus: {
                personality: false
            },
            toggle() {
                this.open = !this.open;
            },
            toggleMenu(name) {
                this.menus[name] = !this.menus[name];
            },
            isOpen(name) {
                return this.menus[name];
            }
        });

        Alpine.data('sidebarComponent', () => ({
            get sidebarClass() {
                return {
                    'w-64': Alpine.store('sidebar').open,
                    'w-20': !Alpine.store('sidebar').open,
                    'bg-white text-black h-screen sticky top-0 left-0 z-40 transition-all duration-300': true
                };
            }
        }));
    });
</script>
<?php /**PATH /home/nativeappdev-console-tribe/htdocs/console-tribe.nativeappdev.com/tribe-laravel/resources/views/livewire/sidebar-menu.blade.php ENDPATH**/ ?>