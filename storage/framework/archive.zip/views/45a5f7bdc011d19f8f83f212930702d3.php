<div>
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Reflection List</h2>

        <!--[if BLOCK]><![endif]--><?php if($alertMessage): ?>
            <div id="alertBox" class="p-4 mb-4 rounded <?php echo e($alertType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                <?php echo e($alertMessage); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin')): ?>
        <div class="flex gap-4 mb-6">
            
            <input type="text" wire:model="searchTopic" placeholder="Search by topic" class="border rounded p-2 w-48">

            
            <select wire:model="orgId" class="border rounded p-2">
                <option value="">All Organisation</option>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $organisationsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($org->id); ?>"><?php echo e($org->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="">No organisations found</option>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </select>

            
            <select wire:model="officeId" class="border rounded p-2">
                <option value="">All Office</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $officesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($office->id); ?>"><?php echo e($office->office); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'organisation_user')): ?>
        <div class="flex justify-end mb-6">
            <a href="<?php echo e(route('reflection.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                New Reflection
            </a>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <div class="overflow-x-auto bg-white shadow rounded">
            <table class="min-w-full text-sm text-left border">
                <thead class="bg-gray-100 text-gray-700 uppercase">
                    <tr>
                        <th class="px-3 py-2">ID</th>
                        <th class="px-3 py-2">Date</th>
                        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin')): ?>
                        <th class="px-3 py-2">Organisation</th>
                        <th class="px-3 py-2">Department</th>
                        <th class="px-3 py-2">Office</th>
                        <th class="px-3 py-2">User Name</th>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <th class="px-3 py-2">Topic</th>
                        <th class="px-3 py-2">Message</th>
                        <th class="px-3 py-2 text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $reflectionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-3 py-2"><?php echo e($r['id']); ?></td>
                            <td class="px-3 py-2"><?php echo e(date('d-m-Y', strtotime($r['created_at']))); ?></td>

                            <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin')): ?>
                            <td class="px-3 py-2"><?php echo e($r['organisation']); ?></td>
                            <td class="px-3 py-2"><?php echo e($r['department']); ?></td>
                            <td class="px-3 py-2"><?php echo e($r['office']); ?></td>
                            <td class="px-3 py-2"><?php echo e($r['userName']); ?></td>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <td class="px-3 py-2"><?php echo e(\Illuminate\Support\Str::limit($r['topic'], 50)); ?></td>
                            <td class="px-3 py-2"><?php echo e(\Illuminate\Support\Str::limit($r['message'], 50)); ?></td>

                            <td class="px-3 py-2 text-center space-x-2">
                                
                                <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin')): ?>
                                    <button type="button" wire:click="confirmDelete('<?php echo e(base64_encode($r['id'])); ?>')" class="text-red-600 hover:underline">
                                        Delete
                                    </button>
                                    <button class="text-blue-600 hover:underline" wire:click="openChat(<?php echo e($r['id']); ?>)">
                                        Chat
                                    </button>
                                <?php else: ?>
                                
                                    <button class="text-blue-600 hover:underline" wire:click="openChat(<?php echo e($r['id']); ?>)">
                                        Chat
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        
        <div class="mt-6">
            <?php echo e($reflectionListTbl->links()); ?>

        </div>

        
        <!--[if BLOCK]><![endif]--><?php if($showChatModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded shadow-lg w-1/2 max-h-[80vh] flex flex-col">
                <div class="flex justify-between items-center p-4 border-b">
                    <h4 class="font-semibold text-lg">Conversation</h4>
                    <button wire:click="$set('showChatModal', false)" class="text-gray-700 text-xl">&times;</button>
                </div>
                <div class="flex-1 overflow-y-auto p-4 space-y-2">
                    <ul>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $chatMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($msg['from'] === auth()->id() ? 'text-right' : 'text-left'); ?>">
                                <div class="inline-block p-2 rounded <?php echo e($msg['from'] === auth()->id() ? 'bg-blue-100' : 'bg-gray-200'); ?>">
                                    <?php echo e($msg['message']); ?>

                                    <!--[if BLOCK]><![endif]--><?php if(!empty($msg['image'])): ?>
                                        <img src="<?php echo e($msg['image']); ?>" class="mt-1 w-24 h-24 object-cover rounded">
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <div class="text-xs text-gray-500 mt-1"><?php echo e($msg['time']); ?></div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
                <div class="p-4 border-t">
                    <form wire:submit.prevent="sendChatMessage">
                        <div class="flex gap-2 items-center">
                            <textarea wire:model.defer="newChatMessage" placeholder="Type Something..." class="flex-1 p-2 border rounded"></textarea>
                            <input type="file" wire:model="newChatImage" class="hidden" id="chatFileInput">
                            <button type="button" onclick="document.getElementById('chatFileInput').click();" class="p-2 bg-gray-200 rounded hover:bg-gray-300">📎</button>
                            <button type="submit" class="p-2 bg-blue-600 text-white rounded hover:bg-blue-700">Send</button>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['newChatMessage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['newChatImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showDeleteModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded shadow-lg w-1/3 p-6">
                <h3 class="text-lg font-semibold mb-4">Delete Reflection</h3>
                <p class="mb-6">Are you sure you want to delete this reflection?</p>
                <div class="flex justify-end gap-2">
                    <button wire:click="$set('showDeleteModal', false)" class="px-4 py-2 rounded border hover:bg-gray-100">Cancel</button>
                    <button wire:click="deleteReflectionConfirmed" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">OK, Delete</button>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <script>
            window.addEventListener('alertTimer', () => {
                setTimeout(() => {
                    const el = document.getElementById('alertBox');
                    if (el) el.remove();
                }, 5000);
            });
        </script>
    </div>
</div>
<?php /**PATH /home/nativeappdev-console-tribe/htdocs/console-tribe.nativeappdev.com/tribe-laravel/resources/views/livewire/reflection-list.blade.php ENDPATH**/ ?>